//
//  Post.swift
//  TaskTechie
//
//  Created by SMH on 25/05/24.
//

// MARK: - Model

import Foundation

struct Post: Decodable {
    let id: Int
    let title: String
    let body: String
}
