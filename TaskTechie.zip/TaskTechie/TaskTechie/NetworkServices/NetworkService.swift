//
//  NetworkService.swift
//  TaskTechie
//
//  Created by SMH on 25/05/24.
//

// MARK: - Network Service

import Foundation

actor NetworkService {
    static let shared = NetworkService()
    
    func fetchPosts(page: Int, limit: Int) async throws -> [Post] {
        let urlString = "https://jsonplaceholder.typicode.com/posts?_page=\(page)&_limit=\(limit)"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        let posts = try JSONDecoder().decode([Post].self, from: data)
        return posts
    }
}

