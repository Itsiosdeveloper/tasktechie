//
//  PostViewModel.swift
//  TaskTechie
//
//  Created by SMH on 25/05/24.
//

// MARK: - ViewModel

import Foundation

@MainActor
class PostViewModel: ObservableObject {
    @Published private(set) var posts: [Post] = []
    private var currentPage = 1
    private let limit = 10
    private var isLoading = false
    
    // MARK: - Data Fetching
    
    func fetchPosts() async {
        guard !isLoading else { return }
        isLoading = true
        
        do {
            let newPosts = try await NetworkService.shared.fetchPosts(page: currentPage, limit: limit)
            posts.append(contentsOf: newPosts)
            currentPage += 1
        } catch {
            print("Failed to fetch posts: \(error)")
        }
        
        isLoading = false
    }
    
    // MARK: - Heavy Computation
    
    private func performHeavyComputation(on post: Post) -> String {
        let startTime = CFAbsoluteTimeGetCurrent()
        
        // Simulate heavy computation
        Thread.sleep(forTimeInterval: 0.1) // Simulate delay
        
        let elapsedTime = CFAbsoluteTimeGetCurrent() - startTime
        print("Heavy computation took \(elapsedTime) seconds")
        
        return "Computed Value for Post \(post.id)"
    }
    
    func computedValueForPost(at index: Int) -> String {
        let post = posts[index]
        return performHeavyComputation(on: post)
    }
}

